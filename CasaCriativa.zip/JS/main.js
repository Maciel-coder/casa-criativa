console.log('Hello World!');

document
  .querySelector("button.fat")
  .addEventListener("click", function() {
      document
        .querySelector("#footer")
        .classList
        .toggle("hide")
  })
  
  //exibindo e ocultando a tela
  //de formulario
document 
  .querySelector("#buttons")
  .addEventListener("click", function(){
      document
        .querySelector("#modal")
        .classList
        .toggle("hide")
      
  })
 

